# -*- coding: utf-8 -*-
{
    'name': "Fix No CSS $o-chatter-min-width",
    'description': """
        Fix No CSS $o-chatter-min-width
    """,

    'author': "OSCG-sha",
    'website': "http://www.oscg.cn",
    'category': 'project',
    'version': '0.1',
    'depends': [
            'web'
        ],
    'data': [
        'views/assets.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
