# -*- coding: utf-8 -*-
# Part of Odoo. 

from . import hr_applicant
from . import hr_contract_salary_advantage
from . import hr_contract
from . import hr_job
from . import res_config_settings
from . import hr_contract_salary_personal_info
from . import hr_contract_salary_resume
from . import hr_salary_structure_type
