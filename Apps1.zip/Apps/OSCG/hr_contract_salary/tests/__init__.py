# -*- coding: utf-8 -*-
# Part of Odoo. 

from . import test_advantages
