# -*- coding: utf-8 -*-
# Part of Odoo. 

from . import generate_simulation_link
