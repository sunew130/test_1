# -*- coding: utf-8 -*-
# Part of Odoo.

from . import hr_contract_salary_resume
