# -*- coding: utf-8 -*-
# Part of Odoo.   

from . import hr_leave_report_calendar
