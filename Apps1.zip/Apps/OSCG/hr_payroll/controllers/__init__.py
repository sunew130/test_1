# -*- coding: utf-8 -*-
# Part of Odoo.   

from . import main
